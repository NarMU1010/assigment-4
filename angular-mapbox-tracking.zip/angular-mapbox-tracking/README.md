# Angular + Mapbox + NgRx + Cypress + CircleCI

App Angular 22 con mapa de Mapbox (ngx-mapbox-gl), una directiva personalizada para registrar
clicks por "tracking tags", contadores reactivos con NgRx, tests unitarios (Jasmine/Karma),
tests e2e (Cypress) e integración continua (CircleCI).

## Puesta en marcha

```bash
npm install
# 1. Pega tu token público de Mapbox (pk.…) en src/app/mapbox.config.ts
npm start            # http://localhost:4200
```

Sin token la app funciona igual, pero en lugar del mapa muestra un aviso.

## Tests

```bash
npm run test:ci      # Jasmine + Karma (ChromeHeadless)
npm run cy:open      # Cypress interactivo (con `npm start` corriendo)
npm run cy:run       # Cypress en consola
```

## Dónde está cada requisito de la rúbrica

| # | Requisito | Archivo |
|---|-----------|---------|
| 1 | `ngx-mapbox-gl` + `@types/mapbox-gl@0.49.0` | `package.json` (`npm ls ngx-mapbox-gl`) |
| 2 | Marker con popup al hacer click | `src/app/components/map-view/` |
| 3 | Componente con animación al cambiar una propiedad | `src/app/components/tracking-panel/tracking-panel.ts` (trigger `bump`) |
| 4 | Directiva personalizada de tracking de clicks | `src/app/directives/track-click.directive.ts` |
| 5 | `ElementRef` inyectado + suscripción al evento `click` | misma directiva (`fromEvent`) |
| 6 | Uso en templates leyendo `data-track-tag` | `src/app/app.html`, `map-view.html` |
| 7 | Redux (NgRx): contadores reactivos en pantalla | `src/app/state/`, `tracking-panel.html` |
| 8 | Spec Jasmine de todos los reducers | `src/app/state/tracking.reducer.spec.ts` |
| 9 | Cypress + ≥3 tests propios | `cypress/e2e/tracking.cy.ts` |
| 10 | CircleCI | `.circleci/config.yml` |
