describe('Tracking de clicks (directiva + NgRx)', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('muestra el estado vacío y el total en 0 al iniciar', () => {
    cy.get('[data-cy=empty-state]').should('be.visible');
    cy.get('[data-cy=total-clicks]').should('have.text', '0');
  });

  it('un click en un botón actualiza el total y los contadores de todos sus tags', () => {
    cy.get('[data-cy=btn-promo]').click(); // tags: promo, home

    cy.get('[data-cy=total-clicks]').should('have.text', '1');
    cy.get('[data-cy=count-promo]').should('have.text', '1');
    cy.get('[data-cy=count-home]').should('have.text', '1');
  });

  it('los contadores se acumulan de forma reactiva entre varios botones', () => {
    cy.get('[data-cy=btn-promo]').click(); // promo, home
    cy.get('[data-cy=btn-info]').click(); //  info, home
    cy.get('[data-cy=btn-info]').click();

    cy.get('[data-cy=total-clicks]').should('have.text', '3');
    cy.get('[data-cy=count-home]').should('have.text', '3');
    cy.get('[data-cy=count-info]').should('have.text', '2');
    cy.get('[data-cy=count-promo]').should('have.text', '1');
  });

  it('el botón "Reiniciar contadores" vuelve todo a cero', () => {
    cy.get('[data-cy=btn-contacto]').click();
    cy.get('[data-cy=total-clicks]').should('have.text', '1');

    cy.get('[data-cy=reset]').click();

    cy.get('[data-cy=total-clicks]').should('have.text', '0');
    cy.get('[data-cy=empty-state]').should('be.visible');
  });
});

describe('Mapa', () => {
  it('muestra el mapa o, si falta el token, el aviso de configuración', () => {
    cy.visit('/');
    cy.get('body').then(($body) => {
      const hasMap = $body.find('mgl-map').length > 0;
      const hasNotice = $body.find('[data-cy=map-placeholder]').length > 0;
      expect(hasMap || hasNotice, 'mapa o aviso visible').to.be.true;
    });
  });
});
