// Archivo de soporte de Cypress (se carga antes de cada spec).
export {};
