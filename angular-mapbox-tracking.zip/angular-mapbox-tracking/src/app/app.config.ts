import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideStore } from '@ngrx/store';
import { provideMapboxGL } from 'ngx-mapbox-gl';
import { MAPBOX_TOKEN } from './mapbox.config';
import { mapReducer, trackingReducer } from './state/tracking.reducer';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideAnimationsAsync(),
    provideStore({ tracking: trackingReducer, map: mapReducer }),
    provideMapboxGL({ accessToken: MAPBOX_TOKEN }),
  ],
};
