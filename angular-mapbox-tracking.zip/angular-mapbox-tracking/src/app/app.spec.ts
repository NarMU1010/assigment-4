import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideNoopAnimations } from '@angular/platform-browser/animations';
import { provideStore } from '@ngrx/store';
import { provideMapboxGL } from 'ngx-mapbox-gl';
import { App } from './app';
import { mapReducer, trackingReducer } from './state/tracking.reducer';

/** Integración: directiva + store real + panel de contadores reactivo. */
describe('App (integración tracking)', () => {
  let fixture: ComponentFixture<App>;
  let root: HTMLElement;

  const text = (selector: string) => root.querySelector(selector)?.textContent?.trim();
  const click = async (selector: string) => {
    (root.querySelector(selector) as HTMLElement).click();
    await fixture.whenStable();
    fixture.detectChanges();
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [
        provideNoopAnimations(),
        provideStore({ tracking: trackingReducer, map: mapReducer }),
        provideMapboxGL({ accessToken: 'YOUR_MAPBOX_ACCESS_TOKEN' }),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(App);
    root = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('inicia con total 0 y sin contadores', () => {
    expect(text('[data-cy=total-clicks]')).toBe('0');
    expect(root.querySelector('[data-cy=empty-state]')).not.toBeNull();
  });

  it('muestra el aviso de token en lugar del mapa si falta el token', () => {
    expect(root.querySelector('[data-cy=map-placeholder]')).not.toBeNull();
  });

  it('un click actualiza total y contadores de cada tag en pantalla', async () => {
    await click('[data-cy=btn-promo]'); // promo, home
    await click('[data-cy=btn-info]'); //  info, home

    expect(text('[data-cy=total-clicks]')).toBe('2');
    expect(text('[data-cy=count-home]')).toBe('2');
    expect(text('[data-cy=count-promo]')).toBe('1');
    expect(text('[data-cy=count-info]')).toBe('1');
  });

  it('reiniciar vuelve el total a 0', async () => {
    await click('[data-cy=btn-contacto]');
    expect(text('[data-cy=total-clicks]')).toBe('1');

    await click('[data-cy=reset]');
    expect(text('[data-cy=total-clicks]')).toBe('0');
  });
});
