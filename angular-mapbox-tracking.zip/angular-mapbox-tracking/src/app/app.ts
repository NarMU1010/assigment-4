import { Component } from '@angular/core';
import { MapView } from './components/map-view/map-view';
import { TrackingPanel } from './components/tracking-panel/tracking-panel';
import { TrackClickDirective } from './directives/track-click.directive';

@Component({
  selector: 'app-root',
  imports: [MapView, TrackingPanel, TrackClickDirective],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
