import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import { MapComponent, MarkerComponent, PopupComponent } from 'ngx-mapbox-gl';
import { TrackClickDirective } from '../../directives/track-click.directive';
import { DEMO_MARKER, hasMapboxToken } from '../../mapbox.config';
import { selectMarker } from '../../state/tracking.actions';
import { AppState, selectSelectedMarkerId } from '../../state/tracking.reducer';

@Component({
  selector: 'app-map-view',
  imports: [MapComponent, MarkerComponent, PopupComponent, TrackClickDirective],
  templateUrl: './map-view.html',
  styleUrl: './map-view.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapView {
  private readonly store = inject<Store<AppState>>(Store);

  protected readonly marker = DEMO_MARKER;
  protected readonly tokenAvailable = hasMapboxToken();
  protected readonly selectedId = toSignal(this.store.select(selectSelectedMarkerId), {
    initialValue: null,
  });

  protected onMarkerClick(): void {
    this.store.dispatch(selectMarker({ markerId: this.marker.id }));
  }
}
