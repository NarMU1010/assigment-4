import { animate, keyframes, style, transition, trigger } from '@angular/animations';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import { resetTracking } from '../../state/tracking.actions';
import { AppState, selectCounters, selectTotalClicks } from '../../state/tracking.reducer';

@Component({
  selector: 'app-tracking-panel',
  templateUrl: './tracking-panel.html',
  styleUrl: './tracking-panel.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    // Se dispara cada vez que CAMBIA el valor ligado a [@bump] (ej. el contador).
    trigger('bump', [
      transition('* => *', [
        animate(
          '350ms ease-out',
          keyframes([
            style({ transform: 'scale(1)', backgroundColor: '#e0f2fe', offset: 0 }),
            style({ transform: 'scale(1.25)', backgroundColor: '#fde68a', offset: 0.4 }),
            style({ transform: 'scale(1)', backgroundColor: '#e0f2fe', offset: 1 }),
          ])
        ),
      ]),
    ]),
  ],
})
export class TrackingPanel {
  private readonly store = inject<Store<AppState>>(Store);

  protected readonly total = toSignal(this.store.select(selectTotalClicks), { initialValue: 0 });
  private readonly counters = toSignal(this.store.select(selectCounters), { initialValue: {} });

  /** Lista ordenada de [tag, count] para pintar en pantalla. */
  protected readonly entries = computed(() =>
    Object.entries(this.counters()).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
  );

  protected reset(): void {
    this.store.dispatch(resetTracking());
  }
}
