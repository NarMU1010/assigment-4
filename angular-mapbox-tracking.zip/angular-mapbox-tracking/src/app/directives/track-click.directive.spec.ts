import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { trackTags } from '../state/tracking.actions';
import { TrackClickDirective } from './track-click.directive';

@Component({
  imports: [TrackClickDirective],
  template: `
    <button id="tracked" appTrackClick data-track-tag="promo, home">A</button>
    <button id="untracked" appTrackClick>B</button>
  `,
})
class HostComponent {}

describe('TrackClickDirective', () => {
  let fixture: ComponentFixture<HostComponent>;
  let dispatch: jasmine.Spy;

  beforeEach(async () => {
    dispatch = jasmine.createSpy('dispatch');
    await TestBed.configureTestingModule({
      imports: [HostComponent],
      providers: [{ provide: Store, useValue: { dispatch } }],
    }).compileComponents();

    fixture = TestBed.createComponent(HostComponent);
    fixture.detectChanges();
  });

  it('lee los tracking tags del elemento y los envía al store al hacer click', () => {
    fixture.nativeElement.querySelector('#tracked').click();
    expect(dispatch).toHaveBeenCalledOnceWith(trackTags({ tags: ['promo', 'home'] }));
  });

  it('no despacha nada si el elemento no tiene tracking tags', () => {
    fixture.nativeElement.querySelector('#untracked').click();
    expect(dispatch).not.toHaveBeenCalled();
  });
});
