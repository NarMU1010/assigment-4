import { DestroyRef, Directive, ElementRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Store } from '@ngrx/store';
import { fromEvent } from 'rxjs';
import { trackTags } from '../state/tracking.actions';
import { AppState } from '../state/tracking.reducer';

/**
 * Directiva para registrar la actividad de clicks del usuario.
 *
 * Uso:   <button appTrackClick data-track-tag="boton-a, promo">Comprar</button>
 *
 * - Recibe el ElementRef por inyección de dependencias.
 * - Se suscribe al evento DOM "click" del elemento.
 * - Lee los "tracking tags" desde el atributo `data-track-tag` (separados por coma)
 *   y los envía al store de NgRx.
 */
@Directive({
  selector: '[appTrackClick]',
})
export class TrackClickDirective {
  private readonly elementRef = inject<ElementRef<HTMLElement>>(ElementRef);
  private readonly store = inject<Store<AppState>>(Store);

  constructor() {
    fromEvent(this.elementRef.nativeElement, 'click')
      .pipe(takeUntilDestroyed(inject(DestroyRef)))
      .subscribe(() => {
        const tags = this.readTrackingTags();
        if (tags.length > 0) {
          this.store.dispatch(trackTags({ tags }));
        }
      });
  }

  private readTrackingTags(): string[] {
    const raw = this.elementRef.nativeElement.getAttribute('data-track-tag') ?? '';
    return raw
      .split(',')
      .map((tag) => tag.trim())
      .filter((tag) => tag.length > 0);
  }
}
