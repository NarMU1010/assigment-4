/**
 * Token público de Mapbox (empieza con "pk.").
 * Créalo gratis en https://account.mapbox.com/access-tokens/ y pégalo aquí.
 * Mientras siga el valor de ejemplo, la app muestra un aviso en lugar del mapa
 * (así el resto de la app, el store y los tests siguen funcionando).
 */
export const MAPBOX_TOKEN = 'YOUR_MAPBOX_ACCESS_TOKEN';

export const hasMapboxToken = (): boolean => MAPBOX_TOKEN.startsWith('pk.');

/** Marker de ejemplo: Tegucigalpa, Honduras. */
export const DEMO_MARKER = {
  id: 'tegucigalpa',
  name: 'Tegucigalpa',
  description: 'Capital de Honduras',
  lngLat: [-87.2068, 14.0723] as [number, number],
};
