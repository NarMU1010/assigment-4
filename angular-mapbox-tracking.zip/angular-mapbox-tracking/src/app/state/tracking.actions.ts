import { createAction, props } from '@ngrx/store';

/** Se dispara cada vez que el usuario hace click en un elemento con "tracking tags". */
export const trackTags = createAction(
  '[Tracking] Track Tags',
  props<{ tags: string[] }>()
);

export const resetTracking = createAction('[Tracking] Reset');

/** El usuario seleccionó (o deseleccionó) el marker del mapa. */
export const selectMarker = createAction(
  '[Map] Select Marker',
  props<{ markerId: string | null }>()
);
