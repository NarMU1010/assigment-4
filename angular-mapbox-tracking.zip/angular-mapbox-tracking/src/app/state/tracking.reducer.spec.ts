import { resetTracking, selectMarker, trackTags } from './tracking.actions';
import {
  initialMapState,
  initialTrackingState,
  mapReducer,
  TrackingState,
  trackingReducer,
} from './tracking.reducer';

describe('trackingReducer', () => {
  it('retorna el estado inicial ante una acción desconocida', () => {
    const state = trackingReducer(undefined, { type: 'unknown' } as never);
    expect(state).toEqual(initialTrackingState);
  });

  it('trackTags: crea el contador en 1 para un tag nuevo', () => {
    const state = trackingReducer(initialTrackingState, trackTags({ tags: ['promo'] }));
    expect(state.counters).toEqual({ promo: 1 });
    expect(state.totalClicks).toBe(1);
  });

  it('trackTags: incrementa tags existentes y soporta varios tags por click', () => {
    let state = trackingReducer(initialTrackingState, trackTags({ tags: ['promo', 'home'] }));
    state = trackingReducer(state, trackTags({ tags: ['promo'] }));
    expect(state.counters).toEqual({ promo: 2, home: 1 });
    expect(state.totalClicks).toBe(2);
  });

  it('trackTags: es una función pura (no muta el estado previo, retorna uno nuevo)', () => {
    const previous: TrackingState = { counters: { promo: 1 }, totalClicks: 1 };
    const snapshot = JSON.parse(JSON.stringify(previous));

    const next = trackingReducer(previous, trackTags({ tags: ['promo'] }));

    expect(previous).toEqual(snapshot);
    expect(next).not.toBe(previous);
    expect(next.counters).not.toBe(previous.counters);
  });

  it('resetTracking: vuelve al estado inicial', () => {
    const dirty: TrackingState = { counters: { a: 5 }, totalClicks: 5 };
    expect(trackingReducer(dirty, resetTracking())).toEqual(initialTrackingState);
  });
});

describe('mapReducer', () => {
  it('retorna el estado inicial ante una acción desconocida', () => {
    expect(mapReducer(undefined, { type: 'unknown' } as never)).toEqual(initialMapState);
  });

  it('selectMarker: selecciona el marker', () => {
    const state = mapReducer(initialMapState, selectMarker({ markerId: 'tegucigalpa' }));
    expect(state.selectedMarkerId).toBe('tegucigalpa');
  });

  it('selectMarker: hacer click otra vez sobre el mismo marker lo deselecciona', () => {
    const selected = mapReducer(initialMapState, selectMarker({ markerId: 'm1' }));
    const toggled = mapReducer(selected, selectMarker({ markerId: 'm1' }));
    expect(toggled.selectedMarkerId).toBeNull();
  });

  it('selectMarker: cambiar a otro marker reemplaza la selección', () => {
    const selected = mapReducer(initialMapState, selectMarker({ markerId: 'm1' }));
    expect(mapReducer(selected, selectMarker({ markerId: 'm2' })).selectedMarkerId).toBe('m2');
  });

  it('selectMarker: es una función pura (no muta el estado previo)', () => {
    const previous = { selectedMarkerId: null };
    const next = mapReducer(previous, selectMarker({ markerId: 'm1' }));
    expect(previous.selectedMarkerId).toBeNull();
    expect(next).not.toBe(previous);
  });

  it('resetTracking: limpia la selección', () => {
    const selected = mapReducer(initialMapState, selectMarker({ markerId: 'm1' }));
    expect(mapReducer(selected, resetTracking())).toEqual(initialMapState);
  });
});
