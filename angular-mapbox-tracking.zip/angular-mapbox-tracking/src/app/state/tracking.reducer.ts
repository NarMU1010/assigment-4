import { createReducer, on } from '@ngrx/store';
import { resetTracking, selectMarker, trackTags } from './tracking.actions';

// ───────── Reducer 1: contadores de tracking tags ─────────

export interface TrackingState {
  /** tag → número de clicks registrados */
  counters: Record<string, number>;
  totalClicks: number;
}

export const initialTrackingState: TrackingState = {
  counters: {},
  totalClicks: 0,
};

export const trackingReducer = createReducer(
  initialTrackingState,
  on(trackTags, (state, { tags }) => {
    // Función pura: se construye un objeto NUEVO, nunca se muta `state`.
    const counters = { ...state.counters };
    for (const tag of tags) {
      counters[tag] = (counters[tag] ?? 0) + 1;
    }
    return { ...state, counters, totalClicks: state.totalClicks + 1 };
  }),
  on(resetTracking, () => initialTrackingState)
);

// ───────── Reducer 2: estado del mapa (marker seleccionado) ─────────

export interface MapState {
  selectedMarkerId: string | null;
}

export const initialMapState: MapState = {
  selectedMarkerId: null,
};

export const mapReducer = createReducer(
  initialMapState,
  on(selectMarker, (state, { markerId }) => ({
    ...state,
    // click sobre el marker ya seleccionado → se deselecciona (toggle)
    selectedMarkerId: state.selectedMarkerId === markerId ? null : markerId,
  })),
  on(resetTracking, () => initialMapState)
);

// ───────── Estado global y selectores ─────────

export interface AppState {
  tracking: TrackingState;
  map: MapState;
}

export const selectCounters = (state: AppState) => state.tracking.counters;
export const selectTotalClicks = (state: AppState) => state.tracking.totalClicks;
export const selectSelectedMarkerId = (state: AppState) => state.map.selectedMarkerId;
